/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   texter.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/21 12:32:37 by mazoukni          #+#    #+#             */
/*   Updated: 2021/12/23 17:57:47 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../Include/so_long.h"

extern struct g_all	g_data;

void	Can_i_Exit(int x, int y)
{
	if ((Are_Collectibles_Gone() == 1 && is_There_a_Wall(x, y, &g_data) == 'E')
		|| g_data.ply.ms == 0)
	{
		if (g_data.ply.ms != 0)
			write(1, "WELCOME BACK TO REAL WORLD!\n", 27);
		Close_Game(&g_data, 1);
		g_data.ply.ms = 0;
	}
	else if (g_data.ply.mr == 1)
		g_data.ply.ms = 1;
	else if (g_data.ply.mr == -1)
		g_data.ply.ms = 2;
	else if (g_data.ply.mup == 1)
		g_data.ply.ms = 3;
	else if (g_data.ply.mup == -1)
		g_data.ply.ms = 4;
}

int	Xpm_ToImage(unsigned int **adr, char *file)
{
	int		fd;
	void	*img;
	int		tab[6];

	if (Check_Filename(file, "xpm") == 0)
		return (-1);
	fd = open(file, O_RDONLY);
	if (fd == -1)
		return (-1);
	close(fd);
	img = mlx_xpm_file_to_image(g_data.mlx.ptr, file, &tab[0], &tab[1]);
	if (img == NULL || tab[0] != 64 || tab[1] != 64)
		return (-1);
	*adr = (unsigned int *)mlx_get_data_addr(img, &tab[2], &tab[3], &tab[4]);
	free(img);
	return (0);
}

int	Save_Textures(char *line, unsigned int **adr, int i)
{
	char		*file;
	int			j;

	Skip_Space(line, &i);
	j = i;
	while (line[i] != ' ' && line[i] != '\0')
		(i)++;
	file = malloc(sizeof(char) * (i - j + 1));
	if (!(file))
		return (-8);
	i = j;
	j = 0;
	while (line[i] != ' ' && line[i] != '\0')
		file[j++] = line[(i)++];
	file[j] = '\0';
	if (*adr != NULL)
		return (-7);
	j = Xpm_ToImage(adr, file);
	free(file);
	if (j == -1)
		return (-9);
	return (0);
}

void	Load_Textures(t_all *s)
{
	s->err.n += Save_Textures("Textures/purplestone.xpm", &g_data.tex.h, 0);
	s->err.n += Save_Textures("Textures/mari.xpm", &g_data.tex.c, 0);
	s->err.n += Save_Textures("Textures/zombieW.xpm", &g_data.tex.pw, 0);
	s->err.n += Save_Textures("Textures/zombieA.xpm", &g_data.tex.pa, 0);
	s->err.n += Save_Textures("Textures/zombieS.xpm", &g_data.tex.ps, 0);
	s->err.n += Save_Textures("Textures/zombieD.xpm", &g_data.tex.pd, 0);
	s->err.n += Save_Textures("Textures/bong2.xpm", &g_data.tex.e, 0);
	s->err.n += Save_Textures("Textures/wall_4.xpm", &g_data.tex.w, 0);
}

int	Update_Exit_Data(int i, int j, int x1, int z)
{
	t_exit	*x;

	x = g_data.exit;
	x1 = -1;
	while (x[++x1].x)
	{
		if (x[x1].x == i && x[x1].y == j)
		{
			if (z == 1)
				x[x1].v = 0;
			return (x[x1].v);
		}
	}
	return (0);
}
