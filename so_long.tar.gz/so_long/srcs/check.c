/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/22 17:20:55 by mazoukni          #+#    #+#             */
/*   Updated: 2021/12/22 18:43:27 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../Include/so_long.h"

extern struct g_all	g_data;

int	Update_Collectible_Data(int i, int j, int x1, int z)
{
	t_weed	*w;

	w = g_data.weed;
	if (x1 == 1)
	{
		x1 = -1;
		while (w[++x1].x)
		{
			if (w[x1].x == i && w[x1].y == j)
			{
				if (z == 1)
					w[x1].v = 0;
				return (w[x1].v);
			}
		}
	}
	else
	{
		return (Update_Exit_Data(i, j, x1, z));
	}
	return (0);
}

int	Are_Collectibles_Gone(void)
{
	int		i;
	t_weed	*w;

	w = g_data.weed;
	i = 0;
	while (i < g_data.err.c)
	{
		if (w[i].v == 1)
			return (0);
		i++;
	}
	return (1);
}

int	Key_Pressed(int key, void *param)
{
	if (key == ESC)
		Close_Game(&g_data, 1);
	if (key == W)
		((t_all *)param)->ply.mup = -1;
	else if (key == S)
		((t_all *)param)->ply.mup = 1;
	else if (key == D)
		((t_all *)param)->ply.mr = 1;
	else if (key == A)
		((t_all *)param)->ply.mr = -1;
	Draw_Game();
	((t_all *)param)->ply.mr = 0;
	((t_all *)param)->ply.mup = 0;
	return (0);
}

int	Parse_Map(t_all *s)
{
	int		i;
	int		j;

	i = -1;
	while (++i < s->map.y)
	{
		j = -1;
		while (++j < s->map.x)
		{
			if (s->map.tab[i][j] == '0' || s->map.tab[i][j] == 'P' ||
				s->map.tab[i][j] == 'E' || s->map.tab[i][j] == 'C')
			{
				if (i == 0 || j == 0 || i == s->map.y - 1
					|| j == s->map.x - 1
					|| s->map.tab[i][j + 1] == '\0' ||
					s->map.tab[i + 1][j] == '\0' ||
					s->map.tab[i - 1][j] == '\0' ||
					s->map.tab[i][j - 1] == '\0')
					return (-1);
			}
		}
	}
	return (1);
}

int	Check_Error(t_all *s)
{
	if (s->win.x <= 0 || s->win.y <= 0)
		return (Error_Occured(-14));
	else if (s->err.n < 0)
		return (Error_Occured(-7));
	else if ((s->tex.pd == NULL || s->tex.h == NULL || s->tex.e == NULL)
		|| (s->tex.w == NULL || s->tex.c == NULL || s->tex.ps == NULL
			|| s->tex.pw == NULL) || s->tex.pa == NULL)
		return (Error_Occured(-15));
	else if (s->err.p == 0)
		return (Error_Occured(-17));
	else if (s->err.m < 0)
		return (Error_Occured(-12));
	else if (s->err.c <= 0)
		return (Error_Occured(-4));
	else if (s->err.e <= 0)
		return (Error_Occured(-3));
	else if (s->err.p > 1)
		return (Error_Occured(-18));
	else if (Parse_Map(s) == -1)
		return (Error_Occured(-19));
	return (1);
}
