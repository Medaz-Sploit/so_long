/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tools2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/23 17:58:07 by mazoukni          #+#    #+#             */
/*   Updated: 2021/12/23 17:58:08 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../Include/so_long.h"

extern struct g_all	g_data;

char	is_There_a_Wall(int x, int y, t_all *s)
{
	int	xX;
	int	xY;

	if (x < 0 || x >= s->win.x || y < 0 || y >= s->win.y)
		return (0);
	xX = floor(x / 64);
	xY = floor(y / 64);
	return (s->map.tab[xY][xX]);
}

int	Check_Filename(char *arg, char *ext)
{
	int	i;

	i = 0;
	while (arg[i] != '\0')
		i++;
	if ((i > 4 && arg[i - 1] == ext[2] && arg[i - 2] == ext[1])
		&& (arg[i - 3] == ext[0] && arg[i - 4] == '.'))
		return (1);
	return (0);
}

int	Add_ToList(char **p, t_weed *w, t_exit *x)
{
	int	i;
	int	j;
	int	cnt;
	int	l;

	cnt = 0;
	i = -1;
	l = 0;
	while (p[++i])
	{
		j = -1;
		while (p[i][++j])
		{
			if (p[i][j] == 'C')
				Add_ToCollectible(i, j, &l, w);
			else if (p[i][j] == 'E')
				Add_ToExit(i, j, &cnt, x);
		}
	}
	return (0);
}

void	Fill_List(t_all *s)
{
	int	exit;
	int	weed;

	weed = Number_OfObjects('C', s->map.tab);
	exit = Number_OfObjects('E', s->map.tab);
	if (s->weed == NULL)
		s->weed = malloc(sizeof(t_weed) * (weed + 1));
	if (s->exit == NULL)
		s->exit = malloc(sizeof(t_exit) * (exit + 2));
	Add_ToList(s->map.tab, s->weed, s->exit);
}

int	Number_OfObjects(char n, char **p)
{
	int	i;
	int	j;
	int	cnt;

	cnt = 0;
	i = -1;
	while (p[++i])
	{
		j = -1;
		while (p[i][++j])
		{
			if (p[i][j] == n)
				cnt++;
		}
	}
	return (cnt);
}
