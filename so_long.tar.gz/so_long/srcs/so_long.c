/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/21 12:39:32 by mazoukni          #+#    #+#             */
/*   Updated: 2021/12/23 17:57:33 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../Include/so_long.h"

t_all	g_data;

int	Init_Game(t_all *s, char *cub)
{
	char	*line;
	int		fd;
	int		ret;

	ret = 1;
	fd = open(cub, O_RDONLY);
	if (fd == -1)
		return (-1);
	while (ret == 1)
	{
		ret = get_next_line(fd, &line);
		if (Read_Map(s, line) == -1)
			ret = -1;
		free(line);
	}
	close(fd);
	g_data.win.x = g_data.map.x * g_data.map.ts;
	g_data.win.y = g_data.map.y * g_data.map.ts;
	Player_Position(s);
	Load_Textures(s);
	Fill_List(s);
	if (ret == -1 || ret == -3)
		return (-1);
	fd = -1;
	return (Check_Error(s));
}

void	Initialize_Extra_Data(void)
{
	g_data.exit = NULL;
	g_data.mlx.ptr = mlx_init();
	g_data.ply.ms = 1;
	g_data.ply.mv = 0;
	g_data.err.c = 0;
	g_data.err.e = 0;
}

void	Initialize_Data(void)
{
	g_data.mlx.ptr = NULL;
	g_data.img.ptr = NULL;
	g_data.img.adr = NULL;
	g_data.win.x = 0;
	g_data.win.y = 0;
	g_data.img.fsh = 0;
	g_data.err.n = 0;
	g_data.err.m = 0;
	g_data.err.p = 0;
	g_data.map.ts = 64;
	g_data.map.tab = NULL;
	g_data.tex.h = NULL;
	g_data.tex.pw = NULL;
	g_data.tex.pd = NULL;
	g_data.tex.ps = NULL;
	g_data.tex.pa = NULL;
	g_data.tex.e = NULL;
	g_data.tex.w = NULL;
	g_data.tex.c = NULL;
	g_data.weed = NULL;
	g_data.map.x = 0;
	g_data.map.y = 0;
	Initialize_Extra_Data();
}

int	main(int agc, char **agv)
{
	Initialize_Data();
	if (agc != 2)
		Error_Occured(-9);
	if (Init_Game(&g_data, agv[1]) < 0)
		Error_Occured(-12);
	g_data.win.ptr = mlx_new_window(g_data.mlx.ptr, g_data.win.x,
			g_data.win.y, "so_long");
	Draw_Game();
	mlx_hook(g_data.win.ptr, 17, 1L << 2, Close_Game, &g_data);
	mlx_hook(g_data.win.ptr, 2, 0, Key_Pressed, &g_data);
	mlx_loop(g_data.mlx.ptr);
}
