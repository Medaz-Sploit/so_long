/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tools3.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/23 17:58:18 by mazoukni          #+#    #+#             */
/*   Updated: 2021/12/23 17:58:19 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../Include/so_long.h"

extern struct g_all	g_data;

void	Add_ToExit(int i, int j, int *cnt, t_exit *x)
{
	x[*cnt].x = j;
	x[*cnt].v = 1;
	x[(*cnt)++].y = i;
	g_data.err.e++;
}

void	Add_ToCollectible(int i, int j, int *l, t_weed *w)
{
	w[(*l)].x = j;
	w[(*l)].v = 1;
	w[(*l)++].y = i;
	g_data.err.c++;
}
