/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/22 17:20:40 by mazoukni          #+#    #+#             */
/*   Updated: 2021/12/23 17:59:28 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include <unistd.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <fcntl.h>
# include <stdio.h>
# include "../minilibx_opengl/mlx.h"
# include "get_next_line.h"

# define NONE 0xFF000000
# define WHITE 0x00FFFFFF
# define BLACK 0x00000000
# define RED 0x00FF0000
# define GREEN 0x0000FF00
# define BLUE 0x000000FF
# define MAGENTA 0x00FF00FF
# define YELLOW 0x00FFFF00
# define CYAN 0x0000FFFF

# define ESC 53
# define W 13
# define A 0
# define S 1
# define D 2

typedef struct s_mlx
{
	void			*ptr;
}				t_mlx;

typedef struct s_win
{
	void			*ptr;
	int				x;
	int				y;
}				t_win;

typedef struct s_err
{
	int				n;
	int				m;
	int				c;
	int				e;
	int				p;
}				t_err;

typedef struct s_img
{
	void			*ptr;
	char			*adr;
	int				n;
	int				fsh;
	int				m;
}				t_img;

typedef struct s_map
{
	char			**tab;
	int				x;
	int				y;
	int				ts;
	int				spr;
}				t_map;

typedef struct s_ply
{
	double			x;
	double			y;
	int				mv;
	int				mr;
	int				mup;
	int				ms;
}				t_ply;

typedef struct s_weed
{
	double			x;
	double			y;
	int				v;
}				t_weed;

typedef struct s_exit
{
	double			x;
	double			y;
	int				v;
}				t_exit;

typedef struct s_tex
{
	unsigned int	*e;
	unsigned int	*c;
	unsigned int	*h;
	unsigned int	*w;
	unsigned int	*pw;
	unsigned int	*pa;
	unsigned int	*ps;
	unsigned int	*pd;
	unsigned int	f;
}				t_tex;

typedef struct g_all
{
	t_mlx			mlx;
	t_win			win;
	t_map			map;
	t_err			err;
	t_ply			ply;
	t_tex			tex;
	t_weed			*weed;
	t_exit			*exit;
	t_img			img;
}				t_all;

int		Error_Occured(int err);
int		ft_putchar_fd(char c, int fd);
int		ft_putnbr_fd(unsigned int n, int fd);
int		Close_Game(t_all *s, int win);
int		Skip_Space(char *line, int *i);
char	is_There_a_Wall(int x, int y, t_all *s);
int		Check_Filename(char *arg, char *ext);
int		Add_ToList(char **p, t_weed *w, t_exit *x);
void	Fill_List(t_all *s);
int		Number_OfObjects(char n, char **p);
void	my_mlx_pixel_put(int x, int y, unsigned int color);
void	Draw_Wall(int i, int j, unsigned int	*v);
void	Draw_Map(void);
void	Update_Player(void);
void	Draw_Game(void);
void	Can_i_Exit(int x, int y);
int		Xpm_ToImage(unsigned int **adr, char *file);
int		Save_Textures(char *line, unsigned int **adr, int i);
void	Load_Textures(t_all *s);
void	Player_Position(t_all *s);
char	*Save_Map(char *line, int i, int x);
int		Stack_Map(t_all *s, char *line, char **tmp);
int		Fill_Map(t_all *s, char *line);
int		Read_Map(t_all *s, char *l);
int		Update_Collectible_Data(int i, int j, int x1, int z);
int		Are_Collectibles_Gone(void);
int		Key_Pressed(int key, void *param);
int		Parse_Map(t_all *s);
int		Check_Error(t_all *s);
int		Init_Game(t_all *s, char *cub);
void	Initialize_Extra_Data(void);
void	Initialize_Data(void);
int		Update_Exit_Data(int i, int j, int x1, int z);
void	Add_ToCollectible(int i, int j, int *l, t_weed *w);
void	Add_ToExit(int i, int j, int *cnt, t_exit *x);

#endif
